//package comp557.a4;
//
//import java.util.ArrayList;
//import java.util.HashMap;
//import java.util.Iterator;
//import java.util.List;
//import java.util.Map;
//import java.util.Random;
//
//import javax.vecmath.Color3f;
//import javax.vecmath.Point2d;
//import javax.vecmath.Point3d;
//import javax.vecmath.Vector3d;
//
////import comp557.a4.FastPoissonDisk;
//
///**
// * Simple scene loader based on XML file format.
// */
//public class Scene {
//    
//    /** List of surfaces in the scene */
//    public List<Intersectable> surfaceList = new ArrayList<Intersectable>();
//	
//	/** All scene lights */
//	public Map<String,Light> lights = new HashMap<String,Light>();
//
//    /** Contains information about how to render the scene */
//    public Render render;
//    
//    /** The ambient light colour */
//    public Color3f ambient = new Color3f();
//
//    /** The depth of recursion for reflection, Fresnel and refraction computations */
//    public int depthMax = 27;
//    
//    /** 
//     * Default constructor.
//     */
//    public Scene() {
//    	this.render = new Render();
//    }
//    
//    /**
//     * renders the scene
//     */
//    public void render(boolean showPanel) {
//        Camera cam = render.camera; 
//        int w = cam.imageSize.width;
//        int h = cam.imageSize.height;
//        
//        // Lights
//		Iterator it = lights.entrySet().iterator(); 
//		List <String> lightNames = new ArrayList <String> (); 
//		List <Light> lightObjs = new ArrayList <Light> (); 
//		while (it.hasNext()) 
//		{
//			Map.Entry mapElement = (Map.Entry) it.next(); 
//			lightNames.add ((String) mapElement.getKey()); 
//			lightObjs.add ((Light) mapElement.getValue()); 
//		}
//        
//		// Super-Sampling Parameters
//		int numberSamples = 16;
//        // Jitter Matrix for Nx MSAA
//        double[] jitterMatrix = new double[numberSamples * 2];
//		
//        // Compute the Jitter Matrix for Super-Sampling
//        computeJitterMatrix(jitterMatrix, numberSamples);
//        
//        // Jitter Matrix for Motion Blur
//        double[] motionJitterMatrix = new double[numberSamples];
//		
//        // Compute the Jitter Matrix for Super-Sampling
//        computeMotionBlurMatrix(motionJitterMatrix, numberSamples);
//        
//    	double[] offset = {0, 0};
//        double[] motionTime = {0, 0, 0};
//    	
//    	// Depth of Field Parameters
//    	int numberSamplesDOF = 5;
//    	/** Helper class for creating a number of Poisson disk random samples in a region */
//       // FastPoissonDisk fpd = new FastPoissonDisk();
//    	// Jitter Matrix for Nx MSAA
//        double[] jitterMatrixDOF = new double[numberSamplesDOF * 2];
//        
//        // Compute the Jitter Matrix for DOF Blur
//        computeJitterMatrix(jitterMatrixDOF, numberSamplesDOF - 1);
//        // Add the original Eye-Position also to the Jitter Matrix
//        jitterMatrixDOF[(numberSamplesDOF - 1) * 2] = 0.0;
//        jitterMatrixDOF[(numberSamplesDOF - 1) * 2 + 1] = 0.0;
//    	
//    	
//        int count = 0;
//        boolean printF = false;
//        boolean printR = false;
//        boolean printC = false;
//        render.init(w, h, showPanel);
//        
//        for ( int j = 0; j < h && !render.isDone(); j++ ) {
//            for ( int i = 0; i < w && !render.isDone(); i++ ) {
//            	// Depth of Field Parameters
//            	Color3f[] colorDOF = new Color3f[numberSamplesDOF];
//            	// Super-Sampling (Multi Sample Anti-Aliasing) Parameters
//            	Color3f[] colorSS = new Color3f[numberSamples];
//            	
//            	// Depth of Field is implemented here
//            	//for (int nd = 0; nd < numberSamplesDOF; nd++)
//            	//{
//            		
//            	
//            	// TODO: Objective 8: SuperSampling - Nx uniform MSAA is implemented here
//                // Multi-Sample Anti-Aliasing (Nx)
//                for (int ns = 0; ns < numberSamples; ns++)
//                {
//                	//Point2d p = new Point2d();
//                	//fpd.get( p, ns, numberSamples );
//                	//double s = getEffectivePupilRadius(cam, 5);
//        		    //double ox = s * p.x; // eye offset from center + effective aperture displacement 
//        		    //double oy = s * p.y;
//                	offset[0] = jitterMatrix[2 * ns];
//                	offset[1] = jitterMatrix[2 * ns + 1];
//                	motionTime[0] = motionJitterMatrix[ns];
//        		    //offset[0] = ox;
//        		    //offset[1] = oy;
//                	// TODO: Objective 1: generate a ray (use the generateRay method)
//                	Ray ray = new Ray();
//                	generateRay(i, j, offset, cam, ray);
//
//                	if (printR == false)
//                	{
//                		printR = true;
//                		System.out.println("Ray");
//                		System.out.println(ray.eyePoint);
//                		System.out.println(ray.viewDirection);
//                	}
//
//                	// TODO: Objective 2: test for intersection with scene surfaces
//                	IntersectResult bestIR = new IntersectResult();
//                	
//                	Color3f color = new Color3f();
//                	color.set(render.bgcolor);
//                	for (Intersectable obj: surfaceList)
//                	{
//                		if ((obj.material == null)) // Scene Node // If object is under-going some Motion
//                		{
//                			obj.intersect(ray, bestIR, motionTime);
//                		}
//                		else if ((obj.material != null) && (obj.velocity > 0)) // If object is under-going some Motion
//                		{
//                			obj.intersect(ray, bestIR, motionTime);
//                		}
//                		else
//                		{
//                			obj.intersect(ray, bestIR);
//                		}
//                	}
//
//                	colorSS[ns] = new Color3f();
//                	colorSS[ns].set(color);
//                	
//                	
//                	// If intersection was found, color the pixel
//            		if (bestIR.t != Double.POSITIVE_INFINITY)
//                	{
//                		// TODO: Objective 3: compute the shaded result for the intersection point (perhaps requiring shadow rays)
//                		// Add Scene Ambient Lighting
//                		color.set(ambient);
//                		color.x = color.x * bestIR.material.diffuse.x;
//                		color.y = color.y * bestIR.material.diffuse.y;
//                		color.z = color.z * bestIR.material.diffuse.z;
//
//                		// Compute Lambertian and Blinn-Phong Shading
//                		Color3f colorLight = new Color3f();
//                		//System.out.println("Pixels = " + i + ", " + j);
//                		colorLight = computeFresnelReflection(lightObjs, cam.from, ray, bestIR, 500, 0);
//                		color.x = color.x + colorLight.x;
//                		color.y = color.y + colorLight.y;
//                		color.z = color.z + colorLight.z;
//                		
//                		// Add the Color to the Samples and average later
//                		colorSS[ns].set(color);
//                	}
//            		
//                }
//                
//                // Average the Colors for the N Samples for MSAA
//                Color3f color = new Color3f(0, 0, 0);
//                for (int ns = 0; ns < numberSamples; ns++)
//                {
//                	color.x = color.x + colorSS[ns].x;
//                	color.y = color.y + colorSS[ns].y;
//                	color.z = color.z + colorSS[ns].z;
//                }
//                color.scale((float)(1.0f / (float)numberSamples));
//                
//            	// Here is an example of how to calculate the pixel value
//            	Color3f c = new Color3f(color);
//            	int r = (int)Math.min(255*c.x, 255);
//                int g = (int)Math.min(255*c.y, 255);
//                int b = (int)Math.min(255*c.z, 255);
//                int a = 255;
//                int argb = (a<<24 | r<<16 | g<<8 | b);    
//                
//                // update the render image
//                render.setPixel(i, j, argb);
//            }
//        }
//        
//        // save the final render image
//        render.save();
//        
//        // wait for render viewer to close
//        render.waitDone();
//        
//    }
//    
//    /**
//     * Generate a ray through pixel (i,j).
//     * 
//     * @param i The pixel row.
//     * @param j The pixel column.
//     * @param offset The offset from the center of the pixel, in the range [-0.5,+0.5] for each coordinate. 
//     * @param cam The camera.
//     * @param ray Contains the generated ray.
//     */
//	public static void generateRay(final int i, final int j, final double[] offset, final Camera cam, Ray ray) {
//		
//		// TODO: Objective 1: generate rays given the provided parameters
//		// Define u,v,w.
//		Vector3d u = new Vector3d();
//		Vector3d v = new Vector3d();
//		Vector3d w = new Vector3d();
//		
//		w.x = -(cam.to.x - cam.from.x);
//		w.y = -(cam.to.y - cam.from.y);
//		w.z = -(cam.to.z - cam.from.z);
//		double d = w.length();
//		
//		w.normalize();
//		
//		u.cross(cam.up, w);
//		u.normalize();
//		
//		v.cross(u, w);
//		v.normalize();
//		
//		// Top, Left, Bottom and Right Calculations.
//		double t = d * Math.tan((cam.fovy/ 2) * Math.PI / 180);
//		double b = -t;
//		double width = cam.imageSize.width;
//        double height = cam.imageSize.height;
//        double r = t * (width / height);
//        double l = -r;
//        
//        //    
//        double us = l + (r - l) * (i + offset[0]) / cam.imageSize.width;
//        double vs = b + (t - b) * (j + offset[1]) / cam.imageSize.height;
//        
//        // 
//        Vector3d s = new Vector3d();
//        s.x = cam.from.x + us * u.x + vs * v.x - d * w.x;
//        s.y = cam.from.y + us * u.y + vs * v.y - d * w.y;
//        s.z = cam.from.z + us * u.z + vs * v.z - d * w.z;
//        
//        Vector3d dv = new Vector3d();
//        dv.sub(s, cam.from);
//        dv.normalize();
//        
//        ray.set(cam.from, dv);
//        
//	}
//	
//	/**
//     * Generate a ray through pixel (i,j).
//     * 
//     * @param i The pixel row.
//     * @param j The pixel column.
//     * @param offset The offset from the center of the pixel, in the range [-0.5,+0.5] for each coordinate. 
//     * @param cam The camera.
//     * @param ray Contains the generated ray.
//     */
//	public static void generateRayDOF(final int i, final int j, final double[] offset, final Camera cam, Ray ray, double focusDistance) {
//		
//		// TODO: Objective 1: generate rays given the provided parameters
//		// Define u,v,w.
//		Vector3d u = new Vector3d();
//		Vector3d v = new Vector3d();
//		Vector3d w = new Vector3d();
//		
//		w.x = -(cam.to.x - cam.from.x);
//		w.y = -(cam.to.y - cam.from.y);
//		w.z = -(cam.to.z - cam.from.z);
//		double d = w.length();
//		
//		w.normalize();
//		
//		u.cross(cam.up, w);
//		u.normalize();
//		
//		v.cross(u, w);
//		v.normalize();
//		
//		// Top, Left, Bottom and Right Calculations.
//		double t = d * Math.tan((cam.fovy/ 2) * Math.PI / 180);
//		double b = -t;
//		double width = cam.imageSize.width;
//        double height = cam.imageSize.height;
//        double r = t * (width / height);
//        double l = -r;
//        
//        //    
//        double us = l + (r - l) * (i + offset[0]) / cam.imageSize.width;
//        double vs = b + (t - b) * (j + offset[1]) / cam.imageSize.height;
//        
//        // 
//        Vector3d s = new Vector3d();
//        s.x = cam.from.x + us * u.x + vs * v.x - d * w.x;
//        s.y = cam.from.y + us * u.y + vs * v.y - d * w.y;
//        s.z = cam.from.z + us * u.z + vs * v.z - d * w.z;
//        
//        Point3d apertureOffset = new Point3d();
//        apertureOffset.x = offset[0] * 125 / 100;
//        apertureOffset.y = offset[1] * 125 / 100;
//        apertureOffset.z = 0.0;
//        
//        Point3d newEyePoint = new Point3d();
//        newEyePoint.add(cam.from, apertureOffset);
//        
//        //focusDistance = 10;
//        
//        Vector3d dv = new Vector3d();
//        dv.sub(s, cam.from);
//        dv.normalize();
//        
//        dv.scale(focusDistance);
//        dv.sub(apertureOffset);
//        dv.normalize();
//        
//        ray.set(newEyePoint, dv);
//        
//	}
//	
//	/**
//	 * Shoot a shadow ray in the scene and get the result.
//	 * 
//	 * @param result Intersection result from raytracing. 
//	 * @param light The light to check for visibility.
//	 * @param root The scene node.
//	 * @param shadowResult Contains the result of a shadow ray test.
//	 * @param shadowRay Contains the shadow ray used to test for visibility.
//	 * 
//	 * @return True if a point is in shadow, false otherwise. 
//	 */
//	public boolean inShadow(final IntersectResult result, final Light light, IntersectResult shadowResult, Ray shadowRay) {
//		
//		// TODO: Objective 5: check for shadows and use it in your lighting computation
//		// Shadow Ray = (point, light - point)
//		Vector3d shadowDirection = new Vector3d();
//		shadowDirection.sub(light.from, result.p);
//		
//		// Set the Shadow Ray
//		shadowRay.eyePoint = result.p;
//		shadowRay.viewDirection = shadowDirection;
//		
//		// Error Term
//		Point3d error = new Point3d(1, 1, 1);
//		error.scale(0.00001);
//		shadowRay.eyePoint.add(error);
//		
//		IntersectResult ir = new IntersectResult();
//		
//		for (Intersectable child: surfaceList)
//    	{
//    		child.intersect(shadowRay, ir);
//    		if (ir.t != Double.POSITIVE_INFINITY)
//    		{
//    			shadowResult = ir;
//    			return true;
//    		}
//    	}
//		
//		return false;
//	}    
//	
//	// Shadow computation using Area Lights
//		public double inShadowAreaLights(final IntersectResult result, final Light light, IntersectResult shadowResult, Ray shadowRay) {
//			// This inShadow function will return an intensity instead of a boolean
//			
//			double intensity = 0; // 0 -> 1, Complete Shadow -> No Shadow
//			boolean inShadow = false;
//			Random rand = new Random();
//			
//			if (light.type.equals("area")) { // Area Lights			
//				// Cap maximum samples!
//				int numSamples = (int) Math.min(light.areaLightSamples, light.areaHeight * light.areaWidth);
//				
//				// Loop variables
//				Vector3d l = new Vector3d();
//				double fullLength = 0;
//				Vector3d error = new Vector3d();
//				Point3d lightFrom = new Point3d();
//				
//				for (int j = 0; j < numSamples; j++) {
//					// l = normalize(light.pos - point)
//					lightFrom.set(light.from);
//					lightFrom.x += rand.nextInt((int) light.areaWidth + 1);
//					lightFrom.y += rand.nextInt((int) light.areaHeight + 1);
//					l.set(lightFrom);
//					l.sub(result.p);
//					fullLength = l.length();
//					l.normalize();
//				
//					// Start a small distance away from surface to avoid shadow rounding errors
//					error.set(l);
//					error.scale(0.00000000001);
//				
//					// shadowRay = (point, light.pos - point)
//					shadowRay.eyePoint.set(result.p);
//					shadowRay.eyePoint.add(error);
//					shadowRay.viewDirection.set(l);
//					
//					inShadow = false;
//					shadowResult = new IntersectResult();
//					for (int i = 0; i < surfaceList.size(); i++) {
//						surfaceList.get(i).intersect(shadowRay, shadowResult);
//						if (shadowResult.t == Double.POSITIVE_INFINITY) continue;
//			    		if (shadowResult.t <= fullLength) {
//			    			inShadow = true;
//			    			break;
//			    		}
//					}
//					if (!inShadow) intensity += 1.0;
//				}
//				//System.out.printf("intensity %f samples %s \n", intensity, numSamples);
//		    	return intensity / (double) numSamples;
//			}
//			
//			else { // Normal Point Light
//				// l = normalize(light.pos - point)
//				Vector3d l = new Vector3d(light.from);
//				l.sub(result.p);
//				double fullLength = l.length();
//				l.normalize();
//				
//				// Start a small distance away from surface to avoid shadow rounding errors
//				Vector3d error = new Vector3d(l);
//				error.scale(0.00000000001);
//				
//				// shadowRay = (point, light.pos - point)
//				shadowRay.eyePoint.set(result.p);
//				shadowRay.eyePoint.add(error);
//				shadowRay.viewDirection.set(l);
//
//		    	for (int i = 0; i < surfaceList.size(); i++) {
//		    		surfaceList.get(i).intersect(shadowRay, shadowResult);
//		    		if (shadowResult.t == Double.POSITIVE_INFINITY) continue;
//		    		if (shadowResult.t <= fullLength) {
//		    			inShadow = true;
//		    			break;
//		    		}
//		    	}
//		    	if (!inShadow) intensity += 1.0;
//		    	return intensity;
//			}
//		}
//	
//	/**
//	 * Shoot a shadow ray in the scene and get the result.
//	 * 
//	 * @param result Intersection result from raytracing. 
//	 * @param light The light to check for visibility.
//	 * @param root The scene node.
//	 * @param shadowResult Contains the result of a shadow ray test.
//	 * @param shadowRay Contains the shadow ray used to test for visibility.
//	 * 
//	 * @return True if a point is in shadow, false otherwise. 
//	 */
//	public void computeJitterMatrix(double[] jitterMatrix, int numberSamples) {
//		boolean addXY = true;
//		
//		if (numberSamples == 1)
//		{
//			jitterMatrix[0] = 0.0;
//			jitterMatrix[1] = 0.0;
//			return;
//		}
//		
//		double equalDiv = Math.sqrt(numberSamples);
//		int division = 2;
//		int numberSamplesX = 0;
//		int numberSamplesY = 0;
//		
//		// Check if equal divisions on both axes are needed, for e.g., 4, 16, 64, 256, etc.
//		if ((equalDiv % 2.0) == 0)
//		{
//			numberSamplesX = (int)Math.sqrt(numberSamples);
//			numberSamplesY = (int)Math.sqrt(numberSamples);
//		}
//		// Check if un-equal divisions on both axes are needed, for e.g., 8, 32, 128, etc.
//		else
//		{
//			numberSamplesX = (int)Math.sqrt(numberSamples * 2);
//			numberSamplesY = (int)Math.sqrt(numberSamples / 2);
//		}
//		
//		// Compute the pixel sub-division centers for the given samples
//		for (int i = 0; i < numberSamplesX; i++)
//		{	
//			double divisionFactorX = 1.0 / (numberSamplesX);
//			
//			if ((i / division) >= 1) 
//			{
//				divisionFactorX = divisionFactorX + divisionFactorX * ((int)(i / division) * 2);
//			}
//			divisionFactorX = divisionFactorX * Math.pow(-1, i);
//			
//			for (int j = 0, k = 0; j < numberSamplesY; j++, k+=2)
//			{
//				double divisionFactorY = 1.0 / (numberSamplesY);
//				if ((j / division) >= 1)
//				{
//					divisionFactorY = divisionFactorY + divisionFactorY * ((int)(j / division) * 2);
//				}
//				divisionFactorY = divisionFactorY * Math.pow(-1, j);
//				jitterMatrix[(i * (int)(numberSamplesX)) + k] = divisionFactorX;
//				jitterMatrix[(i * (int)(numberSamplesX)) + k + 1] = divisionFactorY;
//				//System.out.println(jitterMatrix[(i * (int)(numberSamplesX)) + k] + "," + jitterMatrix[(i * (int)(numberSamplesX)) + k + 1]);
//			}
//		}
//		
//		
//	}    
//	
//	/**
//	 * Compute Lambertian and Blinn-Phong Shading.
//	 * 
//	 * @param result Intersection result from raytracing. 
//	 * @param light The light to check for visibility.
//	 * @param root The scene node.
//	 * @param shadowResult Contains the result of a shadow ray test.
//	 * @param shadowRay Contains the shadow ray used to test for visibility. 
//	 */
//	public Color3f computeShading(List <Light> lightObjs, Point3d camPos, IntersectResult ir) {
//		Vector3d v = new Vector3d(); //viewing vector = (eye - intersect point)
//		Vector3d l = new Vector3d();
//		Vector3d bisector = new Vector3d();
//		
//		Color3f finalLight = new Color3f();
//		
//		// Iterate through all the lights.
//		for (int li = 0; li < lightObjs.size(); li++)
//		{
//			Light light = new Light();
//			light = lightObjs.get(li);
//			
//			boolean inShadow = false;
//			Ray shadowRay = new Ray();
//			IntersectResult shadowIR = new IntersectResult();
//			double intensity = 0.0;
//			
//			intensity = inShadowAreaLights(ir, light, shadowIR, shadowRay);
//			if (1 == 1)
//			{
//				Vector3d lightFrom = new Vector3d(light.from);
//				double power = light.power;
//
//				v.sub(camPos, ir.p);
//				v.normalize();
//				l.sub(lightFrom, ir.p);
//				l.normalize();
//
//				bisector.add(v, l);
//				bisector.normalize();
//
//				// Lambertian Shading
//				Vector3d diffuse = new Vector3d();
//
//				diffuse.x = ir.material.diffuse.x * light.color.x * power * intensity * Math.max(0.0, l.dot(ir.n));
//				diffuse.y = ir.material.diffuse.y * light.color.y * power * intensity * Math.max(0.0, l.dot(ir.n));
//				diffuse.z = ir.material.diffuse.z * light.color.z * power * intensity * Math.max(0.0, l.dot(ir.n));
//
//				// Blinn-Phong Shading
//				Vector3d blinnPhong = new Vector3d();
//
//				blinnPhong.x = ir.material.specular.x * light.color.x * power * intensity * Math.pow(Math.max(0.0,  bisector.dot(ir.n)), ir.material.shinyness);
//				blinnPhong.y = ir.material.specular.y * light.color.y * power * intensity * Math.pow(Math.max(0.0,  bisector.dot(ir.n)), ir.material.shinyness);
//				blinnPhong.z = ir.material.specular.z * light.color.z * power * intensity * Math.pow(Math.max(0.0,  bisector.dot(ir.n)), ir.material.shinyness);
//
//				finalLight.x = finalLight.x + (float)(diffuse.x + blinnPhong.x); 
//				finalLight.y = finalLight.y + (float)(diffuse.y + blinnPhong.y); 
//				finalLight.z = finalLight.z + (float)(diffuse.z + blinnPhong.z);
//			}
//		}
//		
//		return finalLight;
//		
//	}    
//	
//	/**
//	 * // Create Jitter Matrix for Motion Blur Sampling.
//	 * 
//	 * @param result Intersection result from raytracing. 
//	 * @param light The light to check for visibility.
//	 * @param root The scene node.
//	 * @param shadowResult Contains the result of a shadow ray test.
//	 * @param shadowRay Contains the shadow ray used to test for visibility. 
//	 */
//	public void computeMotionBlurMatrix(double[] motionJitterMatrix, int numberMotionSamples) {
//		int count = -1;
//		for (int ji = 0; ji < numberMotionSamples; ji++)
//		{
//			// Divide into N samples along 0 to 1 space
//			count++;
//			double result = 0, divisions = 0;
//			divisions = 1.0 / (double)numberMotionSamples;
//			result = ji * divisions;
//			motionJitterMatrix[count] = result;
//			//System.out.println(result);
//		}
//	}    
//	
//	
//	
//	
//	/** 
//     * Computes the radius of displaced sample points to emulate a given f-stop 
//     * for the current focal length and focus distance settings.
//     * @return
//     */
//    public double getEffectivePupilRadius(Camera cam, double focusDistance) {
//    	double a = 24 / 1000;
//	    double fl = a / Math.tan((cam.fovy / 2) * Math.PI / 180);
//	    double fd = -focusDistance; 
//	    double f = 1/(1/fd+1/fl);
//	    double r = f / 1.2 / 2; // divide by 2 to get radius of effective aperture 
//		return r; 
//    }
//	
//    
//    
//    /**
//	 * Compute Reflections, Fresnel Reflections and Refraction.
//	 * 
//	 * @param result Intersection result from raytracing. 
//	 * @param light The light to check for visibility.
//	 * @param root The scene node.
//	 * @param shadowResult Contains the result of a shadow ray test.
//	 * @param shadowRay Contains the shadow ray used to test for visibility. 
//	 */
//	public Color3f computeFresnelReflection(List <Light> lightObjs, Point3d camPos, Ray ray, IntersectResult ir, double ior, int depth) {
//		Vector3d v = new Vector3d(); //viewing vector = (eye - intersect point)
//		Vector3d l = new Vector3d();
//		Vector3d bisector = new Vector3d();
//		
//		Color3f finalLight = new Color3f();
//		IntersectResult bestIR = new IntersectResult();
//		boolean test = false;
//		if (depth == 0)
//		{
//			bestIR = ir;
//		}
//		
//		if (depth >= depthMax) {
//			finalLight.set(render.bgcolor);
//			return finalLight;
//		}
//		
//		if (depth != 0)
//		{
//			//System.out.println("In Function");
//        	for (Intersectable obj: surfaceList)
//        	{
//        		obj.intersect(ray, bestIR);
//        		if (bestIR.t == Double.POSITIVE_INFINITY)
//        		{
//        			//System.out.println("Doesn't Intersect");
//        			//System.out.println(obj.material.name);
//        		} 
//        		else 
//        		{
//        			System.out.println("Intersects");
//        			//System.out.println(obj.material.name);
//        		}
//        	}
//        	// If the Reflected Ray has no intersections, return a constant color
//        	if (bestIR.t == Double.POSITIVE_INFINITY)
//        	{
//        		//System.out.println("Come here");
//        		Color3f defaultColor = new Color3f(render.bgcolor);
//        		//defaultColor.set(0.5f, 0.5f, 0.5f);
//        		return defaultColor;
//        		//finalLight.set(1.0f, 1.0f, 1.0f);
//    			//return finalLight;
//        	}
//        	//ir = bestIR;
//    		//System.out.println("Done with IR");
//		}
//		
//		// Reflection, Fresnel Reflection and Refraction
//		if (bestIR.material.reflective == 1)
//		{
//			Color3f refractionColor = new Color3f();
//			Color3f reflectionColor = new Color3f();
//			
//			//System.out.println("Hello");
//			
//            // compute fresnel
//            double kr = 0; 
//            double biasCons = 0.0001; 
//            ior = bestIR.material.refIndex;
//            kr = fresnel(ray.viewDirection, bestIR.n, ior);
//            System.out.println("kr = " + kr);
//            boolean outside = ray.viewDirection.dot(bestIR.n) < 0; 
//            Vector3d bias = new Vector3d(bestIR.n);
//            bias.scale(biasCons); 
//            // compute refraction if it is not a case of total internal reflection
//            if (kr < 1 && ior < 500) { 
//                Vector3d refractionDirection = new Vector3d();
//                refractionDirection = refract(ray.viewDirection, bestIR.n, ior);
//                refractionDirection.normalize(); 
//                Vector3d refractionRayOrig = new Vector3d();
//                if (outside) 
//                	refractionRayOrig.sub(bestIR.p, bias);
//                else
//                	refractionRayOrig.add(bestIR.p, bias); 
//                Ray refractionRay = new Ray();
//                refractionRay.eyePoint.set(refractionRayOrig);
//                refractionRay.viewDirection.set(refractionDirection);
//                
//                refractionColor = computeFresnelReflection(lightObjs, camPos, refractionRay, bestIR, ior, depth + 1); 
//            } 
//
//            Vector3d reflectionDirection = new Vector3d();
//            reflectionDirection = reflect(ray.viewDirection, bestIR.n);
//            reflectionDirection.normalize(); 
//           
//            Vector3d reflectionRayOrig = new Vector3d(bestIR.p);
//            if (outside) 
//            	reflectionRayOrig.add(bestIR.p, bias);
//            else
//            	reflectionRayOrig.sub(bestIR.p, bias);  
//            Ray reflectionRay = new Ray();
//            reflectionRay.eyePoint.set(reflectionRayOrig);
//            reflectionRay.viewDirection.set(reflectionDirection);
//            reflectionColor = computeFresnelReflection(lightObjs, camPos, reflectionRay, bestIR, ior, depth + 1); 
//
//            if (ior < 500)
//            {// mix the two
//            reflectionColor.scale((float)kr);
//            refractionColor.scale((float)(1 - kr)); 
//            finalLight.x = finalLight.x + reflectionColor.x + refractionColor.x;
//            finalLight.y = finalLight.y + reflectionColor.y + refractionColor.y;
//            finalLight.z = finalLight.z + reflectionColor.z + refractionColor.z;
//            }
//            else
//            {
//            	reflectionColor.scale((float)kr);
//            	finalLight.x = finalLight.x + reflectionColor.x;
//                finalLight.y = finalLight.y + reflectionColor.y;
//                finalLight.z = finalLight.z + reflectionColor.z;
//                
//            }
//            
//   
//            
//            return finalLight; 
//		}
//		else
//		{
//			//if (depth > 0)
//				//System.out.println("In Lambertian");
//		// Iterate through all the lights.
//		for (int li = 0; li < lightObjs.size(); li++)
//		{
//			Light light = new Light();
//			light = lightObjs.get(li);
//			
//			boolean inShadow = false;
//			Ray shadowRay = new Ray();
//			IntersectResult shadowIR = new IntersectResult();
//			
//			double intensity = 0;
//			intensity = inShadowAreaLights(bestIR, light, shadowIR, shadowRay);
//			inShadow = false;
//			if (1 == 1)
//			{
//				Vector3d lightFrom = new Vector3d(light.from);
//				double power = light.power;
//
//				v.sub(camPos, bestIR.p);
//				v.normalize();
//				l.sub(lightFrom, bestIR.p);
//				l.normalize();
//
//				bisector.add(v, l);
//				bisector.normalize();
//
//				// Lambertian Shading
//				Vector3d diffuse = new Vector3d();
//
//				diffuse.x = bestIR.material.diffuse.x * light.color.x * intensity * power * Math.max(0.0, l.dot(bestIR.n));
//				diffuse.y = bestIR.material.diffuse.y * light.color.y * intensity * power * Math.max(0.0, l.dot(bestIR.n));
//				diffuse.z = bestIR.material.diffuse.z * light.color.z * intensity * power * Math.max(0.0, l.dot(bestIR.n));
//
//				// Blinn-Phong Shading
//				Vector3d blinnPhong = new Vector3d();
//
//				if (bestIR.material.specular.x < 0)
//				{
//					bestIR.material.specular.negate();
//				}
//				
//				blinnPhong.x = bestIR.material.specular.x * light.color.x * intensity * power * Math.pow(Math.max(0.0,  bisector.dot(bestIR.n)), bestIR.material.shinyness);
//				blinnPhong.y = bestIR.material.specular.y * light.color.y * intensity * power * Math.pow(Math.max(0.0,  bisector.dot(bestIR.n)), bestIR.material.shinyness);
//				blinnPhong.z = bestIR.material.specular.z * light.color.z * intensity * power * Math.pow(Math.max(0.0,  bisector.dot(bestIR.n)), bestIR.material.shinyness);
//
//				finalLight.x = finalLight.x + (float)(diffuse.x + blinnPhong.x); 
//				finalLight.y = finalLight.y + (float)(diffuse.y + blinnPhong.y); 
//				finalLight.z = finalLight.z + (float)(diffuse.z + blinnPhong.z);
//			}
//		}
//			return finalLight;
//		}
//		
//		//return finalLight;
//		
//	}    
//    
//	// Compute reflection direction
//	public Vector3d reflect(Vector3d I, Vector3d N) 
//	{ 
//		Vector3d reflectCoeff = new Vector3d(N);
//		double coeff = I.dot(N);
//		reflectCoeff.scale(coeff);
//		reflectCoeff.scale(2);
//		reflectCoeff.sub(I);
//		reflectCoeff.negate();
//	    return reflectCoeff; 
//	} 
//	
//	// Compute refraction direction
//	public Vector3d refract(Vector3d I, Vector3d N, double ior) 
//	{ 
//	    double cosi = Math.max(-1, Math.min(1, I.dot(N))); 
//	    double etai = 1, etat = ior; 
//	    Vector3d n = new Vector3d(N); 
//	    if (cosi < 0) 
//	    { 
//	    	cosi = -cosi; 
//	    } 
//	    else 
//	    { 
//	    	double temp = etai;
//	    	etai = etat;
//	    	etat = temp;
//	    	n.negate(); 
//	    } 
//	    
//	    double eta = etai / etat; 
//	    double k = 1 - eta * eta * (1 - cosi * cosi); 
//	    if (k < 0)
//	    {
//	    	Vector3d t = new Vector3d(0, 0, 0);
//	    	return t;
//	    }
//	    else
//	    {
//	    	Vector3d refract = new Vector3d(I);
//	    	I.scale(eta);
//	    	n.scale(eta * cosi - Math.sqrt(k));
//	    	I.add(n);
//	    	return refract;
//	    }
//	} 
//	
//	// Evaluate Fresnel equation (ration of reflected light for a given incident direction and surface normal) 
//	public double fresnel(Vector3d I, Vector3d N, double ior) 
//	{ 
//		double kr = 0;
//		double cosi = Math.max(-1, Math.min(1, I.dot(N))); 
//	    double etai = 1, etat = ior; 
//	    if (cosi > 0) 
//	    { 
//	    	double temp = etai;
//	    	etai = etat;
//	    	etat = temp; 
//	    }
//	    
//	    // Compute sini using Snell's law
//	    double sint = etai / (etat * Math.sqrt(Math.max(0.0, 1 - cosi * cosi)));
//	    
//	    // Total internal reflection
//	    if (sint >= 1) 
//	    { 
//	        kr = 1.0; 
//	    } 
//	    else 
//	    { 
//	        double cost = Math.sqrt(Math.max(0.f, 1 - sint * sint)); 
//	        cosi = Math.abs(cosi); 
//	        double Rs = ((etat * cosi) - (etai * cost)) / ((etat * cosi) + (etai * cost)); 
//	        double Rp = ((etai * cosi) - (etat * cost)) / ((etai * cosi) + (etat * cost)); 
//	        kr = (Rs * Rs + Rp * Rp) / 2.0; 
//	    }
//	    
//	    // As a consequence of the conservation of energy, transmittance is given by:
//	    // kt = 1 - kr;
//	    
//	    return kr;   
//	} 
//	
//}
//



package comp557.a4;

import java.util.ArrayList;
import java.util.*; 

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import javax.vecmath.Color3f;
import javax.vecmath.Point3d;
import javax.vecmath.Vector3d;

/**
 * Simple scene loader based on XML file format.
 */
public class Scene {
    
    /** List of surfaces in the scene */
    public List<Intersectable> surfaceList = new ArrayList<Intersectable>();
	
	/** All scene lights */
	public Map<String,Light> lights = new HashMap<String,Light>();

    /** Contains information about how to render the scene */
    public Render render;
    
    /** The ambient light colour */
    public Color3f ambient = new Color3f();
    
    /** The depth of recursion for reflection, Fresnel and refraction computations */
    public int depthMax = 27;
    

    /** 
     * Default constructor.
     */
    public Scene() {
    	this.render = new Render();
    }
    
    /**
     * renders the scene
     */
    public void render(boolean showPanel) {
 
        Camera cam = render.camera; 
        int w = cam.imageSize.width;
        int h = cam.imageSize.height;
        
        double[]offset = {0, 0};
        
        Iterator it = lights.entrySet().iterator();
        List<String> lightNames = new ArrayList<String>();
        List<Light> lightObjs = new ArrayList<Light>();
		while (it.hasNext()) { 
            Map.Entry mapElement = (Map.Entry)it.next(); 
            lightNames.add((String)mapElement.getKey());
            lightObjs.add((Light)mapElement.getValue());
        } 
		System.out.println(lightNames.toString());
		System.out.println(lightObjs.toString());
		
		//System.out.println((Math.floor(-0.55));
        
        render.init(w, h, showPanel);
        
        int samples = 16;
        double[][] offsets = calculateOffset(samples); //need to change this to render.samples
        

        boolean printR = false;
        for ( int j = 0; j < h && !render.isDone(); j++ ) {
            for ( int i = 0; i < w && !render.isDone(); i++ ) {
            	Vector3d finalLightTotal = new Vector3d();
            	
                // TODO: Objective 1: generate a ray (use the generateRay method)
            	for(int k = 0; k<offsets.length; k++) {
            		Ray ray = new Ray();
                	generateRay(i, j, offsets[k], cam, ray);

                	boolean flag = false;

                	IntersectResult ir = new IntersectResult();
                	
                	for(Intersectable obj: surfaceList) {
                		obj.intersect(ray, ir);
                	}
                	Vector3d finalLight = new Vector3d();
                	finalLight.set(render.bgcolor);
                	//System.out.println(ir.t);

                	Vector3d color = new Vector3d();
                	if(ir.t != Double.POSITIVE_INFINITY) {
//                		flag = true;
//            			Vector3d v = new Vector3d(); //viewing vector = (eye - intersect point)
//                 		Vector3d l = new Vector3d();
//                 		Vector3d bisector = new Vector3d();
//                 		
//                 		finalLight.x = 0;
//            			finalLight.y = 0;
//            			finalLight.z = 0;
//            			
//            			//Color3f colorLight = computeFresnelReflection(lightObjs, cam.from, ray, ir, 500, 0);
//            			
//            			for(Light lite: lightObjs) {
//            				
//            				Ray shadowRay = new Ray();
//            				IntersectResult shadowIR = new IntersectResult();
//            				//SceneNode sn = new SceneNode();
//            				if(inShadow(ir, lite, shadowIR, shadowRay)) {
//            					//System.out.println("hiii");
//                        		continue;
//            				}
//
//                    		v.sub(cam.from, ir.p);
//                    		l.sub(lite.from, ir.p);
//                    		bisector.add(v, l);
//                    		
//                    		v.normalize();
//                    		l.normalize();
//                    		bisector.normalize();
//                    		ir.n.normalize();
//                    		
//                    		//DIFFUSE LIGHTING
//                    		Vector3d diffuse = new Vector3d();
//                    		diffuse.x = ir.material.diffuse.x * lite.power * lite.color.x * Math.max(0, l.dot(ir.n));
//                    		diffuse.y = ir.material.diffuse.y * lite.power * lite.color.y * Math.max(0, l.dot(ir.n));
//                    		diffuse.z = ir.material.diffuse.z * lite.power * lite.color.z * Math.max(0, l.dot(ir.n));
//                    	
//                    		
//                    		//Blinn Phong LIGHTING
//                    		Vector3d blinnPhong = new Vector3d();
//           
//                    		blinnPhong.x = ir.material.specular.x * lite.power * lite.color.x * Math.pow(Math.max(0,  bisector.dot(ir.n)), ir.material.shinyness);
//                    		blinnPhong.y = ir.material.specular.y * lite.power * lite.color.y * Math.pow(Math.max(0,  bisector.dot(ir.n)), ir.material.shinyness);
//                    		blinnPhong.z = ir.material.specular.z * lite.power * lite.color.z * Math.pow(Math.max(0,  bisector.dot(ir.n)), ir.material.shinyness);
//                    		
//                    		
//                    		//Ambient LIGHTING
//                    		//Vector3d ambient = new Vector3d();
//                    		
//                    		
//                    		finalLight.x += diffuse.x + blinnPhong.x;
//                    		finalLight.y += diffuse.y + blinnPhong.y;
//                    		finalLight.z += diffuse.z + blinnPhong.z;
//                	
//                	}
//       	
//                	finalLight.x += ambient.x* ir.material.diffuse.x;
//            		finalLight.y += ambient.y* ir.material.diffuse.y;
//            		finalLight.z += ambient.z* ir.material.diffuse.z;
            		
            		color = new Vector3d();
            		color.set(ambient);
            		color.x = color.x * ir.material.diffuse.x;
            		color.y = color.y * ir.material.diffuse.y;
            		color.z = color.z * ir.material.diffuse.z;

            		// Compute Lambertian and Blinn-Phong Shading
            		Color3f colorLight = new Color3f();
            		//System.out.println("Pixels = " + i + ", " + j);
            		colorLight = computeFresnelReflection(lightObjs, cam.from, ray, ir, 500, 0);
            		color.x = color.x + colorLight.x;
            		color.y = color.y + colorLight.y;
            		color.z = color.z + colorLight.z;

                    
                }
            	if(ir.t == Double.POSITIVE_INFINITY) {
                	finalLight.x = render.bgcolor.x;
        			finalLight.y = render.bgcolor.y;
        			finalLight.z = render.bgcolor.z;
                }
            	
            	finalLightTotal.add(color);
            		
            		
            }
            	//defineUVW(cam);
            	

            finalLightTotal.x/=offsets.length;
            finalLightTotal.y/=offsets.length;
            finalLightTotal.z/=offsets.length;
                // TODO: Objective 2: test for intersection with scene surfaces
            	//System.out.println(surfaceList.size());
            	
	
        		
        	//System.out.println(finalLight);
            // TODO: Objective 3: compute the shaded result for the intersection point (perhaps requiring shadow rays)

        	Color3f c = new Color3f(finalLightTotal);
        	int r = (int)Math.min(255,(255*c.x));
            int g = (int)Math.min(255,(255*c.y));
            int b = (int)Math.min(255,(255*c.z));
            int a = 255;
            int argb = (a<<24 | r<<16 | g<<8 | b);    
            
            // update the render image
            render.setPixel(i, j, argb);
        }
        
        }
        // save the final render image
        render.save();
        
        // wait for render viewer to close
        render.waitDone();
        
        
        
    }
    
    public double[][] calculateOffset(int samples) {
    	int nx = 0;
    	int ny = 0;
    	
    	
    	
    	double[]offset = new double[2];
    	if(samples==1) {
    		offset[0] = offset[1] = 0.5;
    		nx = ny = 1;
    	}else if(checkPerfectSquare(samples)) {
    		nx = ny = (int)(Math.sqrt(samples));
    		offset[0] = 1.0/(nx*2);
        	offset[1] = 1.0/(ny*2);
        	System.out.println(offset[0]+", "+offset[1]);
    	}else {
    		nx = (int)Math.sqrt(samples * 2);
    		ny = (int)Math.sqrt(samples / 2);
    		offset[0] = (nx == 1)? 0.5: 1.0/(nx*2); 
    		//essentially (int)Math.sqrt(samples * 2) == 1 is the number of samples in x direction, so if the number
    		//of samples is 1 then the offset[0] should be 0
    		//but if the number of samples is 2 then offset should be 1/4 = 0.25 
    		offset[1] = (ny == 1)? 0.5: 1.0/(ny*2);
    	}
    	
    	double stepX, stepY;
        stepX = (offset[0] == 0)? 1: offset[0]*2;
        stepY = (offset[1] == 0)? 1: offset[1]*2;
        
        double[][]offsets = new double[nx*ny][2];
        
        for(int k = 0; k<nx; k++) { //this will only not work when offset[0] = 0
    		
    		for(int l = 0; l<ny; l++) {
    			offsets[k*ny+l][0] = -0.5 + offset[0] + stepX*k;
    			offsets[k*ny+l][1] = -0.5 + offset[1] + stepY*l;
    		}
    		
    	}
        
    	return offsets;

    }
    
    private static boolean checkPerfectSquare(double x)  
    { 

	// finding the square root of given number 
    	double sq = Math.sqrt(x); 
    	return ((sq - Math.floor(sq)) == 0); 
    } 

    
    /**
     * Generate a ray through pixel (i,j).
     * 
     * @param i The pixel row.
     * @param j The pixel column.
     * @param offset The offset from the center of the pixel, in the range [-0.5,+0.5] for each coordinate. 
     * @param cam The camera.
     * @param ray Contains the generated ray.
     */
	public static void generateRay(final int i, final int j, final double[] offset, final Camera cam, Ray ray) {

			//System.out.println(offset[0]+", "+offset[1]);
		// TODO: Objective 1: generate rays given the provided parameters
				// Define u,v,w.
				Vector3d u = new Vector3d();
				Vector3d v = new Vector3d();
				Vector3d dw = new Vector3d();
				
				dw.x = -(cam.to.x - cam.from.x);
				dw.y = -(cam.to.y - cam.from.y);
				dw.z = -(cam.to.z - cam.from.z);
				double d = dw.length();
				
				dw.normalize();
				
				u.cross(cam.up, dw);
				u.normalize();
				
				v.cross(u, dw);
				v.normalize();
				
				// Top, Left, Bottom and Right Calculations.
				double t = d * Math.tan((cam.fovy/ 2) * Math.PI / 180);
				double b = -t;
				double width = cam.imageSize.width;
		        double height = cam.imageSize.height;
		        double r = t * (width / height);
		        double l = -r;
		        
		        //    
		        double us = l + (r - l) * (i + offset[0]) / width;
		        double vs = b + (t - b) * (j + offset[1]) / height;
		        
		        // 
		        Vector3d s = new Vector3d();
		        s.x = cam.from.x + us * u.x + vs * v.x - d * dw.x;
		        s.y = cam.from.y + us * u.y + vs * v.y - d * dw.y;
		        s.z = cam.from.z + us * u.z + vs * v.z - d * dw.z;
		        
		        Vector3d dv = new Vector3d();
		        dv.sub(s, cam.from);
		        dv.normalize();
		        
		        ray.set(cam.from, dv);
		
		
		
	}
	
	public Color3f computeFresnelReflection(List <Light> lightObjs, Point3d camPos, Ray ray, IntersectResult ir, double ior, int depth) {
		Vector3d v = new Vector3d(); //viewing vector = (eye - intersect point)
		Vector3d l = new Vector3d();
		Vector3d bisector = new Vector3d();
		
		Color3f finalLight = new Color3f();
		IntersectResult closestIr = new IntersectResult();
		boolean test = false;
		if (depth == 0)
		{
			closestIr = ir;
		}
		
		if (depth >= depthMax) {
			finalLight.set(render.bgcolor);
			return finalLight;
		}
		
		if (depth != 0)
		{
			//System.out.println("In Function");
        	for (Intersectable obj: surfaceList)
        	{
        		obj.intersect(ray, closestIr);
        		if (closestIr.t == Double.POSITIVE_INFINITY)
        		{
        			//System.out.println("Doesn't Intersect");
        			//System.out.println(obj.material.name);
        		} 
        		else 
        		{
        			System.out.println("Intersects");
        			//System.out.println(obj.material.name);
        		}
        	}
        	// If the Reflected Ray has no intersections, return a constant color
        	if (closestIr.t == Double.POSITIVE_INFINITY)
        	{
        		//System.out.println("Come here");
        		Color3f defaultColor = new Color3f(render.bgcolor);
        		//defaultColor.set(0.5f, 0.5f, 0.5f);
        		return defaultColor;
        		//finalLight.set(1.0f, 1.0f, 1.0f);
    			//return finalLight;
        	}
        	//ir = bestIR;
    		//System.out.println("Done with IR");
		}
		
		// Reflection, Fresnel Reflection and RefractionbestIR
		if (closestIr.material.reflective == 1)
		{
			Color3f refractionColor = new Color3f();
			Color3f reflectionColor = new Color3f();
			
			//System.out.println("Hello");
			
            // compute fresnel
            double kr = 0; 
            double biasCons = 0.0001; 
            ior = closestIr.material.refIndex;
            kr = fresnel(ray.viewDirection, closestIr.n, ior);
            System.out.println("kr = " + kr);
            boolean outside = ray.viewDirection.dot(closestIr.n) < 0; 
            Vector3d bias = new Vector3d(closestIr.n);
            bias.scale(biasCons); 
            // compute refraction if it is not a case of total internal reflectbestIRion
            if (kr < 1 && ior < 500) { 
                Vector3d refractionDirection = new Vector3d();
                refractionDirection = refract(ray.viewDirection, closestIr.n, ior);
                refractionDirection.normalize(); 
                Vector3d refractionRayOrig = new Vector3d();
                if (outside) 
                	refractionRayOrig.sub(closestIr.p, bias);
                else
                	refractionRayOrig.add(closestIr.p, bias); 
                Ray refractionRay = new Ray();
                refractionRay.eyePoint.set(refractionRayOrig);
                refractionRay.viewDirection.set(refractionDirection);
                
                refractionColor = computeFresnelReflection(lightObjs, camPos, refractionRay, closestIr, ior, depth + 1); 
            } 
            
            Vector3d reflectionDirection = new Vector3d();
            reflectionDirection = reflect(ray.viewDirection, closestIr.n);
            reflectionDirection.normalize(); 
           
            Vector3d reflectionRayOrig = new Vector3d(closestIr.p);
            if (outside) 
            	reflectionRayOrig.add(closestIr.p, bias);
            else
            	reflectionRayOrig.sub(closestIr.p, bias);  
            Ray reflectionRay = new Ray();
            reflectionRay.eyePoint.set(reflectionRayOrig);
            reflectionRay.viewDirection.set(reflectionDirection);
            reflectionColor = computeFresnelReflection(lightObjs, camPos, reflectionRay, closestIr, ior, depth + 1); 

            if (ior < 500)
            {// mix the two
            reflectionColor.scale((float)kr);
            refractionColor.scale((float)(1 - kr)); 
            finalLight.x = finalLight.x + reflectionColor.x + refractionColor.x;
            finalLight.y = finalLight.y + reflectionColor.y + refractionColor.y;
            finalLight.z = finalLight.z + reflectionColor.z + refractionColor.z;
            }
            else
            {
            	reflectionColor.scale((float)kr);
            	finalLight.x = finalLight.x + reflectionColor.x;
                finalLight.y = finalLight.y + reflectionColor.y;
                finalLight.z = finalLight.z + reflectionColor.z;
                
            }
            
   
            
            return finalLight; 
		}
		else
		{
			//if (depth > 0)
				//System.out.println("In Lambertian");
		// Iterate through all the lights.
		for (int li = 0; li < lightObjs.size(); li++)
		{
			Light light = new Light();
			light = lightObjs.get(li);
			
			boolean inShadow = false;
			Ray shadowRay = new Ray();
			IntersectResult shadowIR = new IntersectResult();
			
			double intensity = 1;
			intensity = inShadowAreaLights(closestIr, light, shadowIR, shadowRay);
			System.out.println(intensity);
			inShadow = false;
			Vector3d lightFrom = new Vector3d(light.from);
			double power = light.power;

			v.sub(camPos, closestIr.p);
			v.normalize();
			l.sub(lightFrom, closestIr.p);
			l.normalize();

			bisector.add(v, l);
			bisector.normalize();

			// Lambertian Shading
			Vector3d diffuse = new Vector3d();

			diffuse.x = closestIr.material.diffuse.x * light.color.x * intensity * power * Math.max(0.0, l.dot(closestIr.n));
			diffuse.y = closestIr.material.diffuse.y * light.color.y * intensity * power * Math.max(0.0, l.dot(closestIr.n));
			diffuse.z = closestIr.material.diffuse.z * light.color.z * intensity * power * Math.max(0.0, l.dot(closestIr.n));

			// Blinn-Phong Shading
			Vector3d blinnPhong = new Vector3d();

			if (closestIr.material.specular.x < 0)
			{
				closestIr.material.specular.negate();
			}
			
			blinnPhong.x = closestIr.material.specular.x * light.color.x * intensity * power * Math.pow(Math.max(0.0,  bisector.dot(closestIr.n)), closestIr.material.shinyness);
			blinnPhong.y = closestIr.material.specular.y * light.color.y * intensity * power * Math.pow(Math.max(0.0,  bisector.dot(closestIr.n)), closestIr.material.shinyness);
			blinnPhong.z = closestIr.material.specular.z * light.color.z * intensity * power * Math.pow(Math.max(0.0,  bisector.dot(closestIr.n)), closestIr.material.shinyness);

			finalLight.x = finalLight.x + (float)(diffuse.x + blinnPhong.x); 
			finalLight.y = finalLight.y + (float)(diffuse.y + blinnPhong.y); 
			finalLight.z = finalLight.z + (float)(diffuse.z + blinnPhong.z);
		}
			return finalLight;
		}
		
		//return finalLight;
		
	}    
	
	// Compute reflection direction
		public Vector3d reflect(Vector3d I, Vector3d N) 
		{ 
			Vector3d reflectCoeff = new Vector3d(N);
			double coeff = I.dot(N);
			reflectCoeff.scale(coeff);
			reflectCoeff.scale(2);
			reflectCoeff.sub(I);
			reflectCoeff.negate();
		    return reflectCoeff; 
		} 
		
		// Compute refraction direction
		public Vector3d refract(Vector3d I, Vector3d N, double ior) 
		{ 
		    double cosi = Math.max(-1, Math.min(1, I.dot(N))); 
		    double etai = 1, etat = ior; 
		    Vector3d n = new Vector3d(N); 
		    if (cosi < 0) 
		    { 
		    	cosi = -cosi; 
		    } 
		    else 
		    { 
		    	double temp = etai;
		    	etai = etat;
		    	etat = temp;
		    	n.negate(); 
		    } 
		    
		    double eta = etai / etat; 
		    double k = 1 - eta * eta * (1 - cosi * cosi); 
		    if (k < 0)
		    {
		    	Vector3d t = new Vector3d(0, 0, 0);
		    	return t;
		    }
		    else
		    {
		    	Vector3d refract = new Vector3d(I);
		    	I.scale(eta);
		    	n.scale(eta * cosi - Math.sqrt(k));
		    	I.add(n);
		    	return refract;
		    }
		} 
	// Evaluate Fresnel equation (ration of reflected light for a given incident direction and surface normal) 
		public double fresnel(Vector3d I, Vector3d N, double ior) 
		{ 
			double kr = 0;
			double cosi = Math.max(-1, Math.min(1, I.dot(N))); 
		    double etai = 1, etat = ior; 
		    if (cosi > 0) 
		    { 
		    	double temp = etai;
		    	etai = etat;
		    	etat = temp; 
		    }
		    
		    // Compute sini using Snell's law
		    double sint = etai / (etat * Math.sqrt(Math.max(0.0, 1 - cosi * cosi)));
		    
		    // Total internal reflection
		    if (sint >= 1) 
		    { 
		        kr = 1.0; 
		    } 
		    else 
		    { 
		        double cost = Math.sqrt(Math.max(0.f, 1 - sint * sint)); 
		        cosi = Math.abs(cosi); 
		        double Rs = ((etat * cosi) - (etai * cost)) / ((etat * cosi) + (etai * cost)); 
		        double Rp = ((etai * cosi) - (etat * cost)) / ((etai * cosi) + (etat * cost)); 
		        kr = (Rs * Rs + Rp * Rp) / 2.0; 
		    }
		    
		    // As a consequence of the conservation of energy, transmittance is given by:
		    // kt = 1 - kr;
		    
		    return kr;   
		} 
		
	


	/**
	 * Shoot a shadow ray in the scene and get the result.
	 * 
            	int r = (int)(255*c.x);
	 * @param result Intersection result from raytracing. 
	 * @param light The light to check for visibility.
	 * @param root The scene node.
	 * @param shadowResult Contains the result of a shadow ray test.
	 * @param shadowRay Contains the shadow ray used to test for visibility.
	 * 
	 * @return True if a point is in shadow, false otherwise. 
	 */
	public boolean inShadow(final IntersectResult result, final Light light, IntersectResult shadowResult, Ray shadowRay) {
		
		// TODO: Objective 5: check for shdows and use it in your lighting computation
		
		//shadray is shadow ray
		shadowRay.eyePoint = result.p;
		shadowRay.viewDirection = new Vector3d(light.from.x - result.p.x, light.from.y - result.p.y, light.from.z - result.p.z);
		
		shadowRay.viewDirection.normalize();

		Vector3d ass = new Vector3d(1, 1, 1);
		ass.scale(0.0000001);
		shadowRay.eyePoint.add(ass);
		
		for(Intersectable ir: surfaceList) {
			
    		ir.intersect(shadowRay, shadowResult);
    		
    		//float dist1 = new Vector3d(shadowResult.p.x - result.p.x, shadowResult.p.y - result.p.y, shadowResult.p.z - result.p.z);
    		
    		if(shadowResult.t != Double.POSITIVE_INFINITY && shadowResult.t > 1e-9) {
    			return true;
    		}
    			
		}
		return false;
		
		//ir.intersect(shadowRay, shadowResult);
		
		
		
		
		
	}
	
	
	// Shadow computation using Area Lights
		public double inShadowAreaLights(final IntersectResult result, final Light light, IntersectResult shadowResult, Ray shadowRay) {
				// This inShadow function will return an intensity instead of a boolean
				
				double intensity = 0; // 0 -> 1, Complete Shadow -> No Shadow
				boolean inShadow = false;
				Random rand = new Random();
				
				if (light.type.equals("area")) { // Area Lights			
					// Cap maximum samples!
					int numSamples = (int) Math.min(light.areaLightSamples, light.areaHeight * light.areaWidth);
					
					// Loop variables
					Vector3d l = new Vector3d();
					double fullLength = 0;
					Vector3d error = new Vector3d();
					Point3d lightFrom = new Point3d();
					
					for (int j = 0; j < numSamples; j++) {
						// l = normalize(light.pos - point)
						lightFrom.set(light.from);
						lightFrom.x += rand.nextInt((int) light.areaWidth + 1);
						lightFrom.y += rand.nextInt((int) light.areaHeight + 1);
						l.set(lightFrom);
						l.sub(result.p);
						fullLength = l.length();
						l.normalize();
					
						// Start a small distance away from surface to avoid shadow rounding errors
						error.set(l);
						error.scale(0.00000000001);
					
						// shadowRay = (point, light.pos - point)
						shadowRay.eyePoint.set(result.p);
						shadowRay.eyePoint.add(error);
						shadowRay.viewDirection.set(l);
						
						inShadow = false;
						shadowResult = new IntersectResult();
						for (int i = 0; i < surfaceList.size(); i++) {
							surfaceList.get(i).intersect(shadowRay, shadowResult);
							if (shadowResult.t == Double.POSITIVE_INFINITY) continue;
				    		if (shadowResult.t <= fullLength) {
				    			inShadow = true;
				    			break;
				    		}
						}
						if (!inShadow) intensity += 1.0;
					}
					//System.out.printf("intensity %f samples %s \n", intensity, numSamples);
			    	return intensity / (double) numSamples;
				}
				
				else { // Normal Point Light
					// l = normalize(light.pos - point)
					Vector3d l = new Vector3d(light.from);
					l.sub(result.p);
					double fullLength = l.length();
					l.normalize();
					
					// Start a small distance away from surface to avoid shadow rounding errors
					Vector3d error = new Vector3d(l);
					error.scale(0.00000000001);
					
					// shadowRay = (point, light.pos - point)
					shadowRay.eyePoint.set(result.p);
					shadowRay.eyePoint.add(error);
					shadowRay.viewDirection.set(l);

			    	for (int i = 0; i < surfaceList.size(); i++) {
			    		surfaceList.get(i).intersect(shadowRay, shadowResult);
			    		if (shadowResult.t == Double.POSITIVE_INFINITY) continue;
			    		if (shadowResult.t <= fullLength) {
			    			inShadow = true;
			    			break;
			    		}
			    	}
			    	if (!inShadow) intensity += 1.0;
			    	return intensity;
				}
			}
	
	
}
