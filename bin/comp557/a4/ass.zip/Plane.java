package comp557.a4;

import javax.vecmath.Point3d;
import javax.vecmath.Vector3d;

/**
 * Class for a plane at y=0.
 * 
 * This surface can have two materials.  If both are defined, a 1x1 tile checker 
 * board pattern should be generated on the plane using the two materials.
 */
public class Plane extends Intersectable {
    
	/** The second material, if non-null is used to produce a checker board pattern. */
	Material material2;
	
	/** The plane normal is the y direction */
	public static final Vector3d n = new Vector3d( 0, 1, 0 );
    
    /**
     * Default constructor
     */
    public Plane() {
    	super();
    }

        
    @Override
    public void intersect( Ray ray, IntersectResult result ) {
    
        // TODO: Objective 4: intersection of ray with plane
    	
    	if(ray.viewDirection.y == 0) return; //if the ray is on the plane
    	
    	Vector3d pointOnPlane = new Vector3d(1, 0, 1); //plane at y=0
    	
    	
    	Vector3d v = new Vector3d();
    	v.x = pointOnPlane.x - ray.eyePoint.x;
    	v.y = pointOnPlane.y - ray.eyePoint.y;
    	v.z = pointOnPlane.z - ray.eyePoint.z;
	
		double t = v.dot(n)/ray.viewDirection.dot(n);
		
		if(t<0) return;
		if(Math.abs(ray.viewDirection.dot(n)) < 0.0000000000001) return;
    	
    	Point3d intersectionPos = new Point3d();
    
    	if(t < result.t && t>1e-9) {
    		ray.getPoint(t, intersectionPos);
        	
        	result.p.x = intersectionPos.x;
        	result.p.y = intersectionPos.y;
        	result.p.z = intersectionPos.z;
        	
        	result.t = t;

        	result.n.x = n.x;
        	result.n.y = n.y;
        	result.n.z = n.z;
        	
        	if(Math.abs(Math.floor(result.p.x))%2 == 0 && Math.abs(Math.floor(result.p.z))%2 == 1 || Math.abs(Math.floor(result.p.z))%2 == 0 && Math.abs(Math.floor(result.p.x))%2 == 1) {
        		result.material = material2;
        	}else {
        		result.material = material;
        	}
    	
    	}
    	
    	
    	
    	//result.material = material;
//        	int x=0;
//        	int z=0;
//        	if(result.p.x < 0) {
//        		x = Math.
//        	}else {
//        		
//        	}

    	
    	
    	//}else return;
    	
    	
    			
    	//material2 = new Material();
    	
    	
    }
    
    @Override
	public void intersect(Ray ray, IntersectResult result, double[] time) {}
    
}
